package com.xxx.zzz.aall.ioppp.socketlll.engineio.clientsnn;

public class EngineIOExceptionq extends Exception {

    public String transport;
    public Object code;

    public EngineIOExceptionq() {
        super();
    }

    public EngineIOExceptionq(String message) {
        super(message);
    }

    public EngineIOExceptionq(String message, Throwable cause) {
        super(message, cause);
    }

    public EngineIOExceptionq(Throwable cause) {
        super(cause);
    }
}
