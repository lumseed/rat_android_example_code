package com.xxx.zzz.smsp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class SmsPushServiceReciever : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
    }

}
