#!/usr/bin/env python3

from .virus_total import VirusTotal
