
package com.xxx.zzz.aall.okhttp3ll.internalss.cachenn;

import java.io.IOException;

import com.xxx.zzz.aall.okioss.Sinkzaq;

public interface CacheRequestq {
  Sinkzaq body() throws IOException;

  void abort();
}
